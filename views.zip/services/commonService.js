const nodemailer = require("nodemailer");
const models = require('../models');
const { Op } = require("sequelize");
const smtpTransport = require('nodemailer-smtp-transport');
const fs = require('fs');
const ejs = require('ejs');
const constants = require('../config/constants');


module.exports = {
	sendRegisterMail: async (userObj) => {
		const compiled = ejs.compile(fs.readFileSync(`${require('path').resolve('views/templates/welcome_mail.html')}`, 'utf8'));

		const template = compiled({firstName: userObj.first_name});
		const subject= 'Welcome to Hotel Inn';

		const smtpObj = {};
		const authObj = {};

        smtpObj.service = 'gmail';
        smtpObj.secure = true;
        smtpObj.host = 'smtp.google.com';

        authObj.user = constants.mailEmail;
        authObj.pass = constants.mailPassword;

        smtpObj.auth = authObj;
        smtpObj.port = 587;

        const transporter = nodemailer.createTransport(smtpTransport(smtpObj));

        const mailOptions = {
          	from: authObj.user,
          	to: `${userObj.email}`,
          	subject: subject,
          	html: template
        };

        transporter.sendMail(mailOptions, function(error, info){
          	if(error){
            	console.log('__________________________________>................error in sending the mail is here: ', error);
          	}else{
            	console.log('____________________________>............Email sent: ' + info.response);
          	}
        });
	},

    getRoomData: async (fromTime, tillTime) => {
        console.log('_______________****************---------________**formTime is: ', fromTime);
        console.log('_______________****************---------________**tillTime is: ', tillTime);

        let whereQuery = '';
        if(!fromTime && !tillTime){
            fromTime = new Date(Date.now()).toLocaleString();
            tillTime = new Date(Date.now()+1000*60*60*24).toLocaleString();
            fromTime = fromTime.replace(',' , '');
            tillTime = tillTime.replace(',' , '');
        }else if(!fromTime && tillTime){
            fromTime = new Date(Date.now()).toLocaleString();
            fromTime = fromTime.replace(',' , '');
        }else if(fromTime && !tillTime){
            tillTime = new Date(Date.now()+1000*60*60*24).toLocaleString();
            tillTime = tillTime.replace(',' , '');
        }

        whereQuery += `(NOT(('${fromTime}' < hotel_room_bookings.till_time AND '${fromTime}' > hotel_room_bookings.from_time) || ('${tillTime}'>hotel_room_bookings.from_time AND '${tillTime}'<hotel_room_bookings.till_time)) || hotel_room_bookings.from_time is NULL)`;

        let allRoomDataStr = `SELECT hotel_rooms.id AS room_id, hotel_rooms.type_id, hotel_rooms.price, hotel_rooms.quantity, hotel_rooms.description, hotel_room_images.file_path, hotel_room_types.type_name
            FROM hotel_rooms
            LEFT JOIN hotel_room_types ON hotel_rooms.type_id = hotel_room_types.id
            LEFT JOIN hotel_room_images ON hotel_rooms.id = hotel_room_images.room_id
            LEFT JOIN hotel_room_bookings ON hotel_room_bookings.room_id = hotel_rooms.id
            WHERE hotel_rooms.is_active = 1 AND hotel_room_types.is_active = 1 AND ${whereQuery}
            GROUP BY hotel_rooms.id;`;

        let allRoomData = await models.sequelize.query(allRoomDataStr);
        allRoomData = allRoomData[0];

        return allRoomData;

        // let queryStr = `SELECT hotel_room_bookings.*, hotel_rooms.type_id, hotel_rooms.price, hotel_rooms.quantity, hotel_rooms.description, hotel_room_types.type_name
        // FROM hotel_rooms
        // LEFT JOIN hotel_room_types ON hotel_rooms.type_id = hotel_room_types.id
        // LEFT JOIN hotel_room_bookings ON hotel_room_bookings.room_id = hotel_rooms.id
        // ${whereQuery}`;
    },
}
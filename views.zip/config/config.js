module.exports = {
	"development": {
		"username": "root",
		"password": '123456',
		"database": "hotelroom",
		"host": "localhost",
		"dialect": "mysql"
	},
	"test": {
		"username": "root",
		"password": null,
		"database": "hotelroom",
		"host": "127.0.0.1",
		"dialect": "mysql"
	},
	"production": {
		"username": "root",
		"password": null,
		"database": "hotelroom",
		"host": "127.0.0.1",
		"dialect": "mysql"
	},
}
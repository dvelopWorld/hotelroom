module.exports = {
	mailEmail: '2016pietcevishakh116@poornima.org',
	mailPassword: 'piet@123',
}
var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
const models = require('../models');
const {upload} = require("../middlewares/multerUpload");


const adminView = require("../controllers/admin/adminView");
const adminApi = require("../controllers/admin/adminApi");


const checkUserSession = (req, res, next) => {
  if(req.session.admin_data){
    next();
  }else{
    res.redirect('/admin/login');
  }
}

const checkToken = (req, res, next) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).send({auth: false, message: 'No token provided.'});
  
  jwt.verify(token, "gEGO1ZGxdAvwwPN7Ce6NstfHUEwBtVEbXPz", async (err, decoded) => {
    if (err) return res.status(500).send({auth: false, message: 'Failed to authenticate token.'});
    next();
  });
}



/* GET users listing. */
router.get('/', checkUserSession, adminView.dashboard);
router.get('/login', adminView.login);
router.put('/login', adminApi.login);
router.put('/logout', adminApi.logout);
router.get('/add-moderator', checkUserSession, adminView.addModerator);
router.get('/edit-moderator', checkUserSession, adminView.editModerator);
router.post('/add-moderator', checkToken, adminApi.addModerator);
router.get('/moderator-list', checkUserSession, adminView.moderatorList);
router.put('/moderator-list', checkToken, adminApi.moderatorList);
router.get('/add-room-type', checkUserSession, adminView.addRoomType);
router.post('/add-room-type', checkToken, adminApi.addRoomType);
router.get('/edit-room-type', checkUserSession, adminView.editRoomType);
router.get('/room-type-list', checkUserSession, adminView.roomTypeList);
router.put('/room-type-list', checkToken, adminApi.roomTypeList);
router.get('/add-room', checkUserSession, adminView.addRoom);
router.post('/add-room', checkToken, adminApi.addRoom);
router.get('/edit-room', checkUserSession, adminView.editRoom);
router.get('/room-list', checkUserSession, adminView.roomList);
router.put('/room-list', checkToken, adminApi.roomList);
router.get('/room-images', checkUserSession, adminView.roomImage);

router.post('/upload-room-pic', [checkToken, upload.single("file")], adminApi.uploadRoomPic);

module.exports = router;

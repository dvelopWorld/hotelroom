var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
const models = require('../models');


const userApi = require('../controllers/user/userApi');
const userView = require('../controllers/user/userView');


const checkUserSession = (req, res, next) => {
  if(req.session.front_data.id){
    next();
  }else{
    res.redirect('/');
  }
}

const preventUserSession = (req, res, next) => {
  console.log('data', req.session.front_data);
  if(req.session.front_data){
    res.redirect('/');
  }else{
    next();
  }
}


// const checkToken=(req, res, next)=>{
//   const token = req.headers['authorization'];

//   if(!token) return res.status(401).send({auth: false, message: 'No token provided.'});
  
//   jwt.verify(token, "gEGO1ZGxdAvwwPN7Ce6NstfHUEwBtVEbXPz", async (err, decoded) => {
//     if(err) return res.status(401).send({auth: false, message: 'Failed to authenticate token.'});
//     console.log('decod',decoded);
//     // await models.hotel_user.findOne({where:{id: decoded.id}, raw: true}).then(async (data)=>{
//     //   req.user_data = data;
//     // });
//     next();
//   });
// }



/* GET home page. */
router.get('/', userView.dashboard);
router.get('/login', userView.login);
router.put('/login', userApi.login);
router.put('/logout', userApi.logout);
router.get('/register', userView.register);
router.post('/register', userApi.register);
router.put('/get-room-data', userApi.getRoomData);
router.post('/book-room', userApi.bookRoom);

module.exports = router;
